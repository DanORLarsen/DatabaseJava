create procedure withdrawMoney(IN fromID int, IN amount int)
  BEGIN
IF (SELECT Balance FROM customer WHERE customer.UserID = fromID) >amount	THEN
	UPDATE customer SET customer.Balance = (SELECT Balance WHERE UserID =
    fromID)-amount;
ELSE SELECT 'You cant';
SELECT * FROM customer WHERE customer.UserID=fromID;
END IF;
END;

