create procedure `if`()
  BEGIN
IF (SELECT debtToBank FROM loans WHERE loans.UserID = 1) >500 THEN SELECT * FROM person;
ELSE SELECT * FROM customer;
END IF;
END;

