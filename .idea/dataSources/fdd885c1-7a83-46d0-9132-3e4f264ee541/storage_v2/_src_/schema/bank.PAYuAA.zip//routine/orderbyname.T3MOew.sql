create procedure orderByName()
  BEGIN
SELECT * FROM person ORDER BY Name ASC;
END;

