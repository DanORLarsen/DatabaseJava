create procedure deleteCustomer(IN id int)
  BEGIN
DELETE FROM `customer` WHERE UserID = id;
DELETE FROM `loans` WHERE UserID = id;
DELETE FROM `employee`WHERE UserID = id;
DELETE FROM `person` WHERE UserID = id;
END;

