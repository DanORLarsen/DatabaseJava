create procedure debtIntrest(IN FROID int, IN days int)
  BEGIN
DECLARE DtB double DEFAULT ((SELECT DebtToBank FROM loans WHERE UserID = FROID)*0.01);
DECLARE i int DEFAULT 1;
SELECT DtB;
IF (SELECT Balance FROM customer WHERE UserID = FROID) > DtB	
THEN
WHILE i<days 
DO
UPDATE customer SET customer.Balance = (SELECT Balance WHERE UserID = FROID) - DtB
WHERE UserID=FROID;
UPDATE loans SET loans.DebtToBank = (SELECT DebtToBank WHERE UserID = FROID) - DtB
WHERE UserID=FROID;
SET i = i + 1;
SET DtB = ((SELECT DebtToBank FROM loans WHERE UserID = FROID)*0.01);
END WHILE;
ELSE SELECT 'You cant';
END IF;
END;

