create procedure regretTransfer(IN transferNR int)
  BEGIN
IF (SELECT Balance FROM customer WHERE UserID = (SELECT ToID FROM transactions WHERE transactions.TransactionNR = transferNR) > (SELECT transactions.Amount FROM transactions WHERE transactions.TransactionNR = transferNR))
    THEN
UPDATE customer SET customer.Balance = customer.Balance + (SELECT transactions.Amount FROM transactions WHERE transactions.TransactionNR = transferNR)  WHERE UserID = (SELECT FromID FROM transactions WHERE transactions.TransactionNR = transferNR);
UPDATE customer SET customer.Balance = customer.Balance - (SELECT transactions.Amount FROM transactions WHERE transactions.TransactionNR = transferNR)  WHERE UserID = (SELECT ToID FROM transactions WHERE transactions.TransactionNR = transferNR);

DELETE FROM `transactions` WHERE transactions.TransactionNR = transferNR;
    ELSE SELECT 'cant transfer not enough money';
    END IF;
END;

