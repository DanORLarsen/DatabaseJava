create procedure orderByDebt()
  BEGIN
SELECT * FROM person 
JOIN loans on person.UserID = loans.UserID ORDER BY DebtToBank DESC;
END;

