create procedure payDebt(IN fromID int, IN payBack int)
  BEGIN
IF (SELECT Balance FROM customer WHERE customer.UserID=fromID) > payBack
THEN
UPDATE customer SET customer.Balance = (SELECT Balance WHERE UserID = fromID)-payBack;
UPDATE loans SET loans.DebtToBank = (SELECT DebtToBank WHERE UserID = fromID)-payBack;
ELSE SELECT 'NOT ENOUGH MONEY';
END IF;
END;

