create procedure thisCity(IN cityName text)
  BEGIN
SELECT * FROM person WHERE City = cityName;
END;

