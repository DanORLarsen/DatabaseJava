create procedure intrestDay()
  BEGIN
UPDATE customer SET customer.Balance = (SELECT Balance WHERE userID)*1.00003 WHERE customer.UserID;
END;

