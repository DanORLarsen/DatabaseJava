create procedure intrestDebt(IN days int)
  BEGIN
UPDATE loans SET loans.DebtToBank = (SELECT DebtToBank WHERE userID)*POWER(1.0002,days) WHERE loans.UserID;
END;

