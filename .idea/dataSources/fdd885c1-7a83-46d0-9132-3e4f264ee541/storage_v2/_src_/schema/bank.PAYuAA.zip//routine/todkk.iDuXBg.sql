create procedure toDKK()
  BEGIN
UPDATE customer SET customer.Balance = balance*7.46;
END;

