create procedure createCustomer(IN name text, IN adress text, IN city text)
  BEGIN
INSERT INTO `person` (`UserID`, `Name`, `Adress`, `City`) VALUES ((SELECT COUNT(*)+1 FROM `customer`),
name, adress, city);
INSERT INTO `customer` (`UserID`, `Balance`) VALUES ((SELECT COUNT(*) FROM `person`), 0);
INSERT INTO `loans` (`UserID`, `DebtToBank`) VALUES ((SELECT COUNT(*) FROM `person`), 0);
END;

