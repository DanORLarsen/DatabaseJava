create procedure transfer(IN fromID int, IN toID int, IN amount int)
  BEGIN
IF (SELECT Balance FROM customer WHERE customer.UserID=fromID)>amount
THEN
UPDATE customer SET customer.Balance = (SELECT Balance WHERE UserID = toID)+amount;
UPDATE customer SET customer.Balance = (SELECT Balance WHERE UserID = fromID)-amount;
INSERT INTO `transactions` (`FromID`, `Amount`, `ToID`) VALUES (fromID, amount, toID);
ELSE SELECT 'NOT ENOUGH MONEY';
END IF;
END;

