create procedure takeLoan(IN fromID int, IN payBack int)
  BEGIN
UPDATE customer SET customer.Balance = (SELECT Balance WHERE UserID = fromID)+ payBack WHERE customer.UserID = fromID;
UPDATE loans SET loans.DebtToBank = (SELECT DebtToBank WHERE UserID = fromID)+ payBack WHERE loans.UserID = fromID;
END;

