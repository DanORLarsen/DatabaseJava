create procedure depositMoney(IN fromID int, IN amount int)
  BEGIN
UPDATE customer SET customer.Balance = (SELECT Balance WHERE UserID = fromID)+amount WHERE customer.UserID = fromID;
END;

