create procedure theseCities(IN cityName text, IN cityName2 text)
  BEGIN
SELECT * FROM person WHERE City = cityName OR City = cityName2;
END;

