create procedure orderByDate()
  BEGIN
SELECT * FROM person ORDER BY Oprettelse ASC;
END;

